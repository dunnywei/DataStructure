#!/usr/bin/env python
import os
def checkFilecontent(filepath,value,key):
	#dict_temp={'Study Modality':'MR','PatientID':'0000002'}; 
	dict_temp=load_header(filepath);
	if (value=='Study Modality')and(dict_temp['Study Modality']==key):
		print "FIND matched, Current directory is \n",filepath;
		return True;
	else:
		print "no match";
	
	return False;

def list_dicoms( root_dir, value, key):
	listFileM=[];
	for root_lst, dirs_lst, files_lst in os.walk(root_dir):
		for filename in files_lst:
			if filename.endswith(".dcm"):			
				print "START\n";
				entire_filename=os.path.join(root_lst, filename);
				result_checkFileconent=checkFilecontent(entire_filename,value,key);
				if (result_checkFileconent==True):
					listFileM.append(entire_filename);
				print "END\n";

	return listFileM;
	
para_dir="/home/Don Wei/MR/";
para_2='Study Modality';
para_3='MR';
result_list=list_dicoms(para_dir,para_2,para_3);
print "result_list is \n",result_list