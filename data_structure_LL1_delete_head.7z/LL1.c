
#include <stdio.h>
#include <stdlib.h>
struct Node
{
	int data;
	struct Node *next;
};

typedef struct Node Node;

Node* A = NULL;

//adding to the front
void createENode(int _number)
{
	Node *temp = (struct Node *)malloc(sizeof(struct Node));

	if (temp == 0)
	{
		printf("Can't allocate memory \n");
	}
	temp->data = _number;
	temp->next = A;
	A = temp;



	return;
}

void traverseList()
{
	Node* temp1 = A;
	while (temp1 != NULL)
	{
		printf("@traverseList,The data is %d \n", temp1->data);
		temp1 = temp1->next;
	}
}

void deletehead()
{
	Node *temp = A;
	if (A != NULL)
	{
		if ((A->next != NULL))
		{
			A = temp->next;
			free(temp);

		}
		else{
			printf("@A->next==NULL \n");
			free(temp);
			A = NULL;

		}
	}
	else{
		printf("Nothing to delete \n");
	}
}
int main()
{
	printf("hey hey\n");
    createENode(9);
    
	//createENode(10);
	//createENode(11);
	
    traverseList();
	
	deletehead();
	
    traverseList();

	//printf("The value of A->data is %d \n",A->data);
	/*
	addNodeEnd(9);
	traverseList();
	*/
	
	
	return 0;
}

//make clean -f Mymakefile
//make all -f Mymakefile
